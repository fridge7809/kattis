public class util {
    public static boolean checkIfPositive(int number) {
        return number > 0 ? true : false;
    }
}